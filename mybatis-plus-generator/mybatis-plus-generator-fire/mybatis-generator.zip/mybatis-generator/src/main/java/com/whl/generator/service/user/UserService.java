package com.whl.generator.service.user;

import com.whl.generator.entity.user.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author whl
 * @since 2019-04-10
 */
public interface UserService extends IService<User> {

}
