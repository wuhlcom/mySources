package com.whl.generator.controller.user;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author whl
 * @since 2019-04-10
 */
@Controller
@RequestMapping("/user")
public class UserController {

}
