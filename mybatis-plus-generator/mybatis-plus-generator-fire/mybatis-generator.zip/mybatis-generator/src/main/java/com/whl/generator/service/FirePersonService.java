package com.whl.generator.service;

import com.whl.generator.entity.FirePerson;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 联网单位人员和监控中心人员 服务类
 * </p>
 *
 * @author whl
 * @since 2019-04-11
 */
public interface FirePersonService extends IService<FirePerson> {

}
