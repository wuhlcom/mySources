package com.whl.generator.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 联网单位和监控中心 前端控制器
 * </p>
 *
 * @author whl
 * @since 2019-04-11
 */
@RestController
@RequestMapping("/unit")
public class UnitController {

}
