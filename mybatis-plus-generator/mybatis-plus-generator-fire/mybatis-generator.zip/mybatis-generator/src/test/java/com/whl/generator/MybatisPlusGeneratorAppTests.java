package com.whl.generator;


import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;



@RunWith(SpringRunner.class)
@SpringBootTest
public class MybatisPlusGeneratorAppTests {

    // @Autowired
    // private FyCurrencyLogService service;
    //
    // @Test
    // public void contextLoads() {
    //     List<FyCurrencyLog> list = service.list();
    //     for (FyCurrencyLog fyCurrencyLog : list) {
    //         System.out.println(fyCurrencyLog);
    //     }
    // }

}
