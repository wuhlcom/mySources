package com.whl.generator.dao.user;

import com.whl.generator.entity.user.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author whl
 * @since 2019-04-10
 */
public interface UserMapper extends BaseMapper<User> {

}
